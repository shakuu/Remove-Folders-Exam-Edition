﻿//namespace CompressingFiles
//{
//    public interface IFolderZipper
//    {
//        string PathToCompress { get; set; }
//        string TempPath { get; }
//        string ZippedPath { get; }

//        bool CompressFolder();
//        bool CompressTempFolder();
//        bool DeleteTempFolder();
//        bool ExtractToTempFolder();
//    }
//}